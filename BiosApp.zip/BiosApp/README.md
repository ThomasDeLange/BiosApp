# BiosApp

Welkom, voor u ziet u het eindresultaat van de bioscoop app. Hierbij inbegrepen is de documentatie van het functioneel en technish ontwerp.

De  code voor de app kunt u vinden onder het mapje app.
De documentatie kunt u vinden in het mapje Documentatie.

Gemaakt door:

Julian : 2127530
Stephan : 210591
Tobias  : 2124631
Szonja  : 2128202
Thomas : 2125564
